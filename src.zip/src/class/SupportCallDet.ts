export class SupportCalldet{
    EmergencyId:number = 2
    ErrorTypeId:number = 0
    ModuleId:number = 0
    ProjectId:number = 0
    CallTypeId:number = 1
    EmployeeId:number = 0
    CustomerId:number = 0
      
    WorkAssignDate:any
    WorkRefNo:string| null= null;
    CalledBy:string| null= null
    SctId:string| null= null
    LoginEmpId:string| null= null
    CalledDesc:string=''
    AttachFile:string| null= null
    WorkStatusId:string|null=null
    // Retval:string| null= null



    CustomerName:string=''
    ProjectName:string=''
    ModuleName:string=''

        
}