export class LeaveRequest{
      FromDate :any
      ToDate :any
      StatusId :string='1'
      CreateUser :string=''
      LeaveReason :string=''
      LeaveRequestDate :any
      LEAVE_REQUEST_ID: string=''
      P_LEAVE_TYPE_ID : string=''
}