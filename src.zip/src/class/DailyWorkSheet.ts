export class DailyWorkSheet{
     WorkId :string=''
     TotalWorkPercentage  :string=''
     TotalWorkHours  :string=''
     TotalWorkMinutes  :string=''
     WorkDate  :any
     CreateUser  :string=''
     StatusId  :string=''
     ProgressNote  :string=''

     EmpId:number=0

     WorkDtlsId:string=''
}