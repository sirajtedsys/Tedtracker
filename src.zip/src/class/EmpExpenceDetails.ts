export class EmpExpenceDetails{
    EmpExpId: string='';
    AccMasterId: string='';
    ExpDtlAmt: string='';
    ExpDtlRemark: string='';
    ExpDtlSlno: string='';
    ActiveStatus: string='';


    ACC_MASTER_NAME:string=''
  
}