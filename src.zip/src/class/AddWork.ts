export class Addwork{
     ProjectWorkDate:any  
      ProjectId:string=''  
      ModuleId:string=''  
      ContactName:string=''  
      ContactNo:string=''  
      CalledDescription:string=''  
 ProjectWorkStatusId:number=0


 ProjectName:string=''
 ModuleName:string=''
}