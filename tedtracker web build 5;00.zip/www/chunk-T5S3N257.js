var _=class{constructor(){this.P_WORK_ID=null,this.P_CALL_ID=null,this.P_EMP_ID=null,this.P_CREATE_USER=null,this.P_CALL_NOTE=null}};export{_ as a};
