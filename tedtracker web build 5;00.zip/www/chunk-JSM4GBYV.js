var s=class{constructor(){this.StatusId="1",this.LeaveReason="",this.LEAVE_REQUEST_ID=""}};export{s as a};
