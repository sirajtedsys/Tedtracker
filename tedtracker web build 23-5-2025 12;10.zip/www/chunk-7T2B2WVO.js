var h=class{constructor(){this.P_OPR_ID=0,this.PunchId=0,this.PunchType=0,this.EmpId="0",this.Hdr=0,this.PunchFrom=null,this.ProjectId=null,this.PunchRemarks=""}};export{h as a};
