export class LeaveRequest{
      FromDate :any
      ToDate :any
      StatusId :string='1'
    //   CreateUser :string=''
      LeaveReason :string=''
      LeaveRequestDate :any
}