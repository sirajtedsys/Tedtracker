var e=r=>r&&r.dir!==""?r.dir.toLowerCase()==="rtl":(document==null?void 0:document.dir.toLowerCase())==="rtl";export{e as a};
